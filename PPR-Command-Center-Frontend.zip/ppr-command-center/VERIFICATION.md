# Verification — 4 October 2026

Built with Node.js v24.19.0. No runtime npm dependencies.

## Completed checks

- `npm run build`: built the complete public/admin.js bundle from editable sources and embedded licensed PDF font.
- `node --check public/admin.js`: valid JavaScript syntax.
- `bash -n scripts/install.sh`: valid installer syntax.
- `npm test`: 11 tests pass, zero fail. Isolated synthetic test inputs are confined to test/; the frontend contains no seeded demo customers, leads or messages.
- Tested response validation, safe state parsing, service mapping, private WhatsApp-ID labelling, separate entity metrics, search, date/service/stage/status filters, capped-contact joins, actual XLSX creation, formula-like text safety, Unicode PDF and pagination, same-origin bearer API use.
- Excel ZIP integrity passes; openpyxl opens the workbook and verifies formula-like enquiry text is a string rather than a formula.
- PDF opens with pypdf; three pages, expected heading/footer, Unicode text and final record present. Rendered page inspected with Poppler. Fixed missing header/footer glyph mapping during verification, then reran the checks.
- Ran the provided installer against the original local PPR backend project. It backed up the prior files and replaced only public/index.html, public/admin.js, public/style.css.
- Reused the original backend locally with an isolated empty SQLite test database. Static asset routes /, /admin.js, /style.css and existing /health and /catalog all return 200. Unauthenticated overview returns 401; authenticated overview returns the actual empty test database arrays.

## Not claimed

No live customer data, production tokens, EC2 access or WhatsApp connection were provided. No live staff actions were submitted. Tests of populated records used isolated model fixtures, not seeded runtime data.

The cloud browser rejected navigation to the local preview address (ERR_BLOCKED_BY_CLIENT). Therefore browser-executed navigation, modal behaviour, viewport rendering and downloads were not visually verified in this environment. Responsive CSS and mobile card layouts are implemented; test them on your own served dashboard before relying on production use.

The frontend follows the existing API contract; that API's snapshot/history limits remain. Excel preserves Unicode; the lightweight PDF writer's font does not fully support complex Indic shaping or emoji. These limitations are documented in README.md.

## Deployment smoke test

1. Back up/install the three static files using the installer.
2. Rebuild the existing Docker service only if its static files are baked into the image.
3. Sign in with the existing ADMIN_TOKEN; verify real snapshot counts.
4. Open each sidebar section and compare contact/lead/outbox details against the backend.
5. Test instant search and applied filters, then clear them.
6. Open a real customer's detail drawer; confirm unavailable history is labelled.
7. Mark a designated test lead contacted; verify backend state after refresh.
8. Export XLSX/PDF under a filter; open both and verify counts/data.
9. Check mobile navigation, cards, charts and full-screen drawer.
10. Sign out; confirm the desk and customer drawer contents clear.

Do not retry an uncertain real message merely to test the UI. Check WhatsApp delivery first.
