# PPR WhatsApp Command Center — frontend project

A complete frontend for your existing PPR Node.js backend on port 3090. Includes editable source and already-built files. Plain JavaScript, HTML and CSS: no npm dependencies, external CDN, separate database, new backend or paid service.

## Features

- Professional login, dark sidebar, light workspace, green/blue accents and responsive layouts.
- Dashboard with eight snapshot KPIs, contacts, leads and service/status charts.
- WhatsApp customer directory, customer detail drawer, saved enquiries and available outgoing activity.
- Leads with real backend status changes, conversation filters, human handoffs and stopped contacts.
- Outbox with attempts, errors, next attempts, retry/discard after explicit confirmation.
- Global instant search, date/service/status filters, pagination and 20-second refresh (15/20/30 seconds or manual).
- Read-only service catalogue taken from the website configuration.
- Actual `.xlsx` export with Contacts, Leads, Outbox, Summary, Analytics and Report info worksheets.
- Downloadable multi-page PDF with business heading, filter metadata, KPIs, contacts, leads and distributions.
- Empty/error states, session-memory token, safe text rendering, local exports and keyboard-accessible drawer.

This dashboard does not add native buttons to WhatsApp messages. It is the administration frontend requested in your attached specification.

## Step 1 — transfer and extract

Download `PPR-Command-Center-Frontend.zip`, upload it to your Ubuntu server and extract it beside your existing automation folder. Do not overwrite the whole backend project.

Example (adjust paths to where you uploaded it):

```bash
cd ~
unzip PPR-Command-Center-Frontend.zip
cd ppr-command-center
```

## Step 2 — identify the existing automation folder

Use the **PPR automation project**, not `~/OpenWA`. The target should have `src/http.js`, `public/`, `compose.yaml` and your current `.env`. It is the project that runs on port 3090.

For example, if the folder is `~/ppr-whatsapp`:

```bash
bash scripts/install.sh "$HOME/ppr-whatsapp"
```

The script validates the target, backs up the three previous frontend files into a dated `frontend-backup-*` directory and replaces only:

```text
public/index.html
public/admin.js
public/style.css
```

Nothing under src/, no `.env`, no database or OpenWA configuration is changed. If your folder has a different name, pass its actual absolute path. File copy permission failures are reported; do not run blindly against a guessed folder.

## Step 3 — make the existing server use the files

### Existing Docker installation

If your backend runs in Docker and the public directory is baked into its image, rebuild only its existing service:

```bash
cd "$HOME/ppr-whatsapp"
sudo docker compose up -d --build --no-deps ppr-bot
```

Use your actual folder/service name if different. This briefly restarts the existing bot; its configured persistent SQLite volume remains in place. Do not run `docker compose down -v`. Do not create another database or new service.

If your backend already bind-mounts `public/`, files update directly and an image rebuild may not be necessary.

### Existing direct Node installation

The original server reads these static files for each request. After copying, refresh the browser. If your process manager caches static files, restart only the existing application using its current process-manager command.

## Step 4 — open and sign in

Open the same dashboard URL you already use on port 3090. Enter your existing **ADMIN_TOKEN**. It is not your OpenWA API key. Do not paste tokens into ChatGPT or embed them into source files.

On a server kept private, use your existing VPN or an SSH tunnel from your computer:

```bash
ssh -L 3090:127.0.0.1:3090 ubuntu@YOUR_EC2_PUBLIC_IP
```

Then open http://127.0.0.1:3090 on that computer while the tunnel stays connected. Keep public staff access behind HTTPS and your existing access restrictions. The frontend does not change server security settings.

The token is kept only in page memory. A page reload or Sign out requires re-entry. Every request uses `Authorization: Bearer <ADMIN_TOKEN>`. No localStorage, sessionStorage or cookies hold the token.

## API contract — unchanged

Data: `GET /api/admin/overview`

```text
{ business: string, dryRun: boolean, contacts: [...], leads: [...], outbox: [...] }
```

Contact fields: `chat`, JSON-encoded `state`, `updated` (epoch milliseconds). State may contain `stage`, `service` (website service ID), `name`.

Lead fields: `id`, `chat`, `name`, `service`, `enquiry`, `status`, `created` (epoch milliseconds).

Outgoing fields: `id`, `chat`, `text`, `status`, `attempts`, `created`, optional `next`, `error`.

Actions: `POST /api/admin/action`, JSON body:

```text
{ type: "pause", chat }
{ type: "resume", chat }
{ type: "lead-status", id, status: "new" | "contacted" | "closed" }
{ type: "discard", id }
{ type: "retry", id, confirmed: true }
```

All changes wait for the backend response and refresh the data. There are no fake local state changes. Resume, retry and discard require a confirmation in the UI. Review/failed messages are the only ones offered retry/discard; pending messages are not incorrectly offered unsupported actions.

The UI uses the exact original static paths `/`, `/admin.js` and `/style.css`, so its routes fit the existing HTTP server without changes. Sections are hash routes (`#leads`, `#analytics`), not additional backend URLs. Do not open index.html as a local file or run it on an unrelated origin: same-origin API calls require the existing backend.

The legacy `/catalog` route also uses `/style.css`; the stylesheet includes compatibility styles for that service page. Its route and generating code remain untouched.

## Data interpretation and limits

- Current original backend returns latest 200 contacts, 200 leads and 100 outgoing records. The UI calls these **loaded snapshot totals**, not lifetime business totals. It cannot retrieve older records through the existing endpoints. Filtering and exports operate on the loaded snapshot.
- Contacts, leads and outbox replies are different entities. A contact can have zero or several leads.
- WhatsApp private `@lid` IDs are labelled **Phone unavailable · private ID**. Their digits are not displayed as a real phone number.
- Name, service and enquiry are inferred only from the stored flow state or loaded lead records. Missing data is labelled unavailable/not collected.
- First-contact dates, full incoming message history, selection timestamps and staff action timestamps are absent. The detail drawer does not invent them. Saved lead enquiries are labelled records, not reconstructed chat bubbles.
- The contacts-over-time chart is honestly labelled **Contact last activity over time** because only `updated` exists. Leads-over-time uses `created`. No unsupported percentage trends are shown.
- Human mode means automation is paused; it is not proof that a staff member replied. Sent means send acceptance as reported by the backend; read/delivery receipts are absent.
- Global dates use the browser's local calendar date: contact last activity, lead/message creation. Report metadata records browser timezone. Page status tabs also constrain that page's exports; table pagination does not limit exported rows.
- Services displays public website definitions bundled in `src/business.json`, not a live backend settings editor. Update them to match your backend's service IDs before rebuilding if you changed that configuration.
- Auto-refresh pauses in background tabs. A failed refresh keeps the last successful snapshot visible with an error notice; 401 signs out and clears sensitive records. Requests time out after 12 seconds.

## Excel and PDF exports

Both formats are generated locally with your applied filters, current instant-search value and relevant page status tab. No third-party network requests. No production data is bundled in this project.

Excel uses inline strings for text, so customer values beginning with `=` are data, not executable spreadsheet formulas. It preserves Unicode text.

PDF embeds the included DejaVu Sans font. Common Latin, Greek and Cyrillic text is supported. Complex Indic script shaping and emoji are not fully supported by this lightweight PDF writer; use the Excel export to preserve such customer text exactly. Reports include all matching loaded records and paginate long enquiries. Include the font license when redistributing.

Exports contain customer contact/enquiry data. Handle downloaded reports under your office's normal privacy controls.

## Edit, build and test

```bash
cd ppr-command-center
npm run build
npm test
```

No `npm install` required. Node 20+ builds/tests the frontend; the existing backend can continue using its current Node 24 runtime.

- `src/app.js`: UI, authentication and API actions.
- `src/model.js`: state parsing, data joins, filters and metrics.
- `src/exports.js`: XLSX and PDF writers.
- `src/business.json`: read-only public service definitions.
- `src/report-font.ttf`, `src/FONT-LICENSE.txt`: bundled PDF font.
- `public/index.html`, `style.css`: layout and responsive styling.
- `public/admin.js`: generated single-file bundle, ready to install.
- `scripts/build.js`: repeatable build using Node only.
- `scripts/install.sh`: backs up and installs only the three frontend assets.
- `test/frontend.test.js`: isolated unit tests with synthetic test inputs only; no runtime demo data.

## Undo the frontend installation

Copy the three files back from the backup directory printed by install.sh, then rebuild the existing Docker service if needed. The installer never deletes previous frontend versions. It does not back up the database because it never edits it.

## Validation

See `VERIFICATION.md` for actual checks and limits. Live EC2 integration is not claimed; no production credentials were supplied. Complete a check on your own server: sign in, inspect real contacts, test filters/drawer, change a test lead status, verify the saved status after refresh, export both formats, sign out and confirm the desk is cleared.
