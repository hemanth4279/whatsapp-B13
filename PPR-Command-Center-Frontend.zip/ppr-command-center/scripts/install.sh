#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ $# -ne 1 ]]; then
  echo "Usage: bash scripts/install.sh /absolute/path/to/existing/ppr-whatsapp"
  exit 1
fi
backend_root="$(cd -- "$1" && pwd)"
if [[ ! -f "$backend_root/src/http.js" || ! -d "$backend_root/public" ]]; then
  echo "This is not the existing PPR backend project: expected src/http.js and public/. Nothing copied."
  exit 1
fi
backup_dir="$backend_root/frontend-backup-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -m 700 -- "$backup_dir"
for file in index.html admin.js style.css; do
  if [[ -f "$backend_root/public/$file" ]]; then cp -p -- "$backend_root/public/$file" "$backup_dir/$file"; fi
  cp -- "$project_root/public/$file" "$backend_root/public/$file"
done
echo "Installed three frontend files. Previous files: $backup_dir"
echo "Backend source, environment and database were not changed."
echo "If Docker baked public/ into its image, rebuild ONLY the existing ppr-bot service."
